from terminal_functions import TerminalFunction


class CommandHandler:
    COMMANDS = {
        1: ("Sort command (directory_name)"),
        2: ("Clean command (file_name, window_size)"),
        3: ("Stat command (file_name)"),
        4: ("Script command (Not implemented yet)"),
        5: ("Exit")
    }

    def __str__(self):
        return ''.join([f"\n{str(key)}) {CommandHandler.COMMANDS[key]}" for key in CommandHandler.COMMANDS])


class MiniTerminal(TerminalFunction):

    def __init__(self):
        self.commands = CommandHandler()

    def parse_command(self, command: str):
        '''
        :param command:
        :return:
        '''
        arrs = command.split(' ')
        if arrs[0] == "1":
            if len(arrs) == 2:
                return self.sort(arrs[1])
            return "missing or more arguments for set sort command"

        elif arrs[0] == "2":
            if len(arrs) == 3:
                return self.clean(arrs[1], arrs[2])
            return "missing or more arguments for set clean command"

        elif arrs[0] == "3":
            if len(arrs) == 2:
                return self.stat(arrs[1])
            return "missing or more arguments for set stat command"

        elif arrs[0] == "5":
            if len(arrs) == 1:
                return exit()
        else:
            return f"Error: cannot find command number: {arrs[0]}"


if __name__ == '__main__':
    import time

    mt = MiniTerminal()
    while True:
        print(mt.commands)
        t = input("Choose the command from menu with correct path or window: ")
        print(t)
        print(mt.parse_command(t))
        time.sleep(0.5)
