import subprocess, time, re
from configfiles.testdata import TestData

config = TestData()


class TerminalFunction():
    count_sort_pass = {}
    count_clean_pass = {}
    count_sort_fail = {}
    count_clean_fail = {}

    def get_hash(self, key):
        '''
        generate hash table according to summing of ascii chars and module 10
        :param key:
        :return:
        '''
        h = 0
        for char in key:
            h += ord(char)
        return h % 10

    def sort(self, directory):
        '''
         Automaticly print and generate mixed.log.txt or mixed1.log.txt with file name and hash table.
         Correct input: 1 mixed; 1 mixed1;    Incorrect input: 1; 1 miy; 1uuuu; 1 yt oo rr
        :param directory:
        :return:
        '''
        general_path = config.get_data('default', 'general_path')
        path_to_log = config.get_data('default', 'path_to_log')
        result = []
        error = []
        d = {}
        d['INPUT'] = directory
        l = []

        process = subprocess.Popen('dir ' + general_path + directory,
                                   shell=True,
                                   stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE)
        for err in process.stderr:
            error.append(err.decode("utf-8").strip('\r\n'))

        if error == []:
            for line in process.stdout:
                result.append(line.decode("utf-8"))

            for line in result:
                if re.search("csv|mat|dxl", line):
                    l.append(''.join([i for i in line.split(' ') if i != ''][-1:]).strip('\r\n'))
            d['OUTPUT'] = l
            d['RESULT'] = rf"{path_to_log}{directory}.log.txt"
            for k, v in d.items():
                if isinstance(v, list):
                    for i in v:
                        print(f'{k}: {i}, hash: {self.get_hash(i)}\n')
                        with open(rf"{path_to_log}{directory}.log.txt", "a+", ) as file:
                            file.write(f'{i}, hash: {self.get_hash(i)}\n')
                else:
                    print(f'{k}: {v}\n')
            try:
                self.count_sort_pass[directory] += 1
            except:
                self.count_sort_pass[directory] = 1
            return d
        else:
            try:
                self.count_sort_fail[directory] += 1
            except:
                self.count_sort_fail[directory] = 1
            return (''.join(error), 'dir ' + general_path + directory)

    def clean(self, directory, window):
        '''
        Print status and keep window of lines in mixed.log.txt or mixed1.log.txt and if window bigger
        than threshold so keep threshold size.
        Correct input: 2 mixed 6; 2 mixed1 8;    Incorrect input: 2; 2 miy 8; 2uuuu; 2 yt oo rr
        :param directory:
        :param window:
        :return:
        '''
        DELITION_THRESHOLD = config.get_data('default', 'DELITION_THRESHOLD')
        path_to_log = config.get_data('default', 'path_to_log')
        result = "window didn't achive the threshold"
        try:
            fd = open(rf"C:\Home_Assignment\log\{directory}.log.txt", "r")
            f = fd.read()
            fd.close()

            l = f.split("\n")
            if int(window) > int(DELITION_THRESHOLD):
                window = int(DELITION_THRESHOLD)
                result = 'window is maintained'
            fd = open(rf"{path_to_log}{directory}.log.txt", "w+")
            for i in range(len(l[-int(window):])):
                fd.write(l[i] + '\n')
            fd.close()
            d = {'INPUT': directory, 'OUTPUT': 'NONE', 'RESULT': result}
            for k, v in d.items():
                print(f'{k}: {v}\n')
            try:
                self.count_clean_pass[directory] += 1
            except:
                self.count_clean_pass[directory] = 1
            return d
        except FileNotFoundError:
            try:
                self.count_clean_fail[directory] += 1
            except:
                self.count_clean_fail[directory] = 1
            return "File does not exist"

    def stat(self, log_folder):
        '''
        Automaticcaly updating, sorting and print status of Sort and Clean commands.
        Correct input: 3 mixed; 3 mixed1;      Incorrect input: 3; 3 nn jjj
        :param log_folder:
        :return:
        '''
        stat_list = []
        # if os.path.isfile(rf"C:\Home_Assignment\log\{log_folder}.log.txt"):
        try:
            stat_list.append(('sort_pass', self.count_sort_pass[log_folder]))
        except:
            stat_list.append(('sort_pass', 0))
        try:
            stat_list.append(('sort_fail', self.count_sort_fail[log_folder]))
        except:
            stat_list.append(('sort_fail', 0))
        try:
            stat_list.append(('clean_pass', self.count_clean_pass[log_folder]))
        except:
            stat_list.append(('clean_pass', 0))
        try:
            stat_list.append(('clean_fail', self.count_clean_fail[log_folder]))
        except:
            stat_list.append(('clean_fail', 0))
        stat_list = sorted(stat_list, key=lambda x: x[1], reverse=True)
        d = {'INPUT': log_folder, 'OUTPUT': stat_list, 'RESULT': 'statistics are provided'}
        for k, v in d.items():
            if isinstance(v, list):
                for i in v:
                    print(f'{k}: {i}\n')
            else:
                print(f'{k}: {v}\n')
